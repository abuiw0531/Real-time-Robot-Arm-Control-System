import cv2
import config
import serial
import time
from utils import HandControlDetector, ControllerButton, RectangleButton

def main():
    # --- 狀態變數初始化 ---
    repeatCounter = 0
    current_command = ""
    a_status = 0
    
    is_aperture_mode = False  # 記錄目前是否處於鎖定模式
    is_pressing_A = False     # 防止長按 A 鍵重複切換模式
    
    # --- 1. 初始化相機與偵測器 ---
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap = cv2.VideoCapture(0) # Fallback
        
    cap.set(3, config.CAM_WIDTH)
    cap.set(4, config.CAM_HEIGHT)

    detector = HandControlDetector(detection_con=0.8, max_hands=1)

    # --- 1.5 初始化 Serial 連線 ---
    try:
        ser = serial.Serial(config.SERIAL_PORT, config.BAUD_RATE, timeout=1)
        print(f"Serial port {config.SERIAL_PORT} opened successfully at {config.BAUD_RATE} baud.")
        time.sleep(2) # 等待連線穩定
    except Exception as e:
        print(f"Failed to open serial port {config.SERIAL_PORT}: {e}")
        ser = None

    def send_command(cmd_str):
        # 負責將字串送到終端機與 Pico
        print(f"Outputting: {cmd_str}")
        if ser and ser.is_open:
            ser.write((cmd_str + '\n').encode('utf-8'))

    # --- 2. 配置按鈕 (加入 A 與 四周的按鈕) ---
    W = config.CAM_WIDTH
    H = config.CAM_HEIGHT
    
    # L: 左側 20%, R: 右側 20%, F: 剩下中間的頂部 25%, B: 剩下中間的底部 25%
    rect_L = (0, 0, int(W * 0.2), H)
    rect_R = (int(W * 0.8), 0, W, H)
    rect_F = (int(W * 0.2), 0, int(W * 0.8), int(H * 0.25))
    rect_B = (int(W * 0.2), int(H * 0.75), int(W * 0.8), H)

    buttons = [
        ControllerButton((W // 2, H // 2), 'circle', 'A', size=50),
        RectangleButton(rect_F, 'F'),
        RectangleButton(rect_B, 'B'),
        RectangleButton(rect_L, 'L'),
        RectangleButton(rect_R, 'R'),
    ]

    while True:
        success, img = cap.read()
        if not success:
            break
            
        img = cv2.flip(img, 1)
        
        # 尋找手部
        hands, img = detector.find_hands(img, draw=True, flip_type=False)

        # 預設此幀變數
        a_clicked_this_frame = False
        aperture = 0 # 預設距離

        if hands:
            hand1 = hands[0]
            lmList = hand1['lmList']
            
            p_thumb = lmList[4][:2]
            p_index = lmList[8][:2]
            p_middle = lmList[12][:2]
            
            # --- Aperture 距離 ---
            aperture, info_ap, img = detector.get_distance(p_thumb, p_index, img) # (4與8號點距離)
            
            # --- 點擊距離 ---
            length_dir, info_dir, img = detector.get_distance(p_index, p_middle, img)
            x, y = p_index  # 使用食指座標當作點擊位置
            
            # 判斷點擊
            if length_dir < config.CLICK_DISTANCE_THRESHOLD: 
                for btn in buttons:
                    if btn.is_clicked(x, y):
                        if btn.value == 'A':
                            a_clicked_this_frame = True
                            if not is_pressing_A:
                                # 點擊 A 下一瞬間立刻切換是否為鎖定 Aperture 模式
                                is_aperture_mode = not is_aperture_mode
                                is_pressing_A = True
                        else:
                            # 只有在非鎖定模式下，才允許四方方向按鈕觸發
                            if not is_aperture_mode:
                                if repeatCounter == 0:
                                    current_command = btn.value
                                    send_command(f"CMD:{current_command}")
                                    repeatCounter = 1 # 開始計數
                                    
            if is_aperture_mode:
                # 若為鎖定模式：僅判定 aperture 以決定輸出 A 狀況，<75為1
                new_a_status = 1 if aperture < 75 else 0
                if new_a_status != a_status:
                    a_status = new_a_status
                    send_command(f"A:{a_status}")
                    
        # 釋放 A 按鈕判定 (防止手在框內導致連續切換跳動)
        if not a_clicked_this_frame:
            is_pressing_A = False

        # --- 處理持續輸出的計時器 ---
        if repeatCounter != 0:
            repeatCounter += 1
            if repeatCounter >= config.INTERVAL:
                repeatCounter = 0

        # --- 繪製按鈕 ---
        # 判斷繪畫：如果是 A 就看 is_aperture_mode；其他的根據按起來的效果或是失能模式 `is_disabled` 來切換
        for btn in buttons:
            if btn.value == 'A':
                btn.draw(img, is_active=is_aperture_mode)
            else:
                btn.draw(img, is_active=(current_command == btn.value and repeatCounter > 0), is_disabled=is_aperture_mode)

        # --- 根據鎖定模式繪製不同的反饋文字給 USER ---
        if is_aperture_mode:
             # 僅印出鎖定文字與 0/1 給 USER 看
            cv2.putText(img, "Aperture Mode Locked", (50, 50), 
                        cv2.FONT_HERSHEY_DUPLEX, 1.2, (0, 0, 255), 2)
            
            a_color = (0, 0, 255) if a_status == 1 else (255, 0, 0)
            cv2.putText(img, f"A: {a_status}", (50, 100), 
                        cv2.FONT_HERSHEY_DUPLEX, 1.2, a_color, 2)
        else:
            cv2.putText(img, "Normal Mode", (50, 50), 
                        cv2.FONT_HERSHEY_DUPLEX, 1.2, (0, 255, 0), 2)
            if hands:
                # 僅在有手部時才顯示 Aperture 原始數值資訊
                cv2.putText(img, f"Aperture Raw: {int(aperture)}", (50, 100), 
                            cv2.FONT_HERSHEY_DUPLEX, 1.2, (255, 100, 0), 2)
            cv2.putText(img, f"Direction: {current_command}", (50, 150), 
                        cv2.FONT_HERSHEY_DUPLEX, 1.2, (0, 200, 0), 2)

        cv2.imshow('Virtual Remote Control', img)
        if cv2.waitKey(1) & 0xFF == ord('q'): 
            break

    cap.release()
    cv2.destroyAllWindows()
    if ser and ser.is_open:
        ser.close()

if __name__ == "__main__":
    main()
